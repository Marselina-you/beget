<h1>Главная страница</h1>
<p>Добро пожаловать на демо версию сайта интернет магазина
разрабатываемого в обучающих статьях блога  LifeExample.ru</p>

<p>Ссылки на уроки:</p>
<ul>
<li><a href="http://lifeexample.ru/php-primeryi-skriptov/pishem-internet-magazin-na-php.html">Введение</li>
<li><a href="http://lifeexample.ru/php-primeryi-skriptov/mvc-fundament-internet-magazina.html">MVC – фундамент интернет магазина (Урок №1)</li>
<li><a href="http://lifeexample.ru/php-primeryi-skriptov/moduli-internet-magazina.html">Модули интернет магазина (Урок №2)</li>
</ul>
